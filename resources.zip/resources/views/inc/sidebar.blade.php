<div class="navbarEcon fixed-top" id="navbarEco">
<div class="container">
  <div class="row">
      <div class="col-md-12">
          
        <nav class="navbar navbar-expand-lg  navStyle">
            <a class="brand-navbar" href="#"><img src="images/ECOPAPER.png" class="img-respopnsive" style="max-width:100%; height:110px;"></a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#mainMenu">
                <span><i class="fas fa-align-right iconStyle" style="color:#fff;"></i></span>
            </button>
            <div class="collapse navbar-collapse" id="mainMenu">
                <ul class="navbar-nav  navList">
                    <li class="nav-item active"><a href="#" class="nav-link"> HOME<span class="sr-only">(current)</span></a></li>
                    <li class="nav-item">
                        <a href="#aboutus" class="nav-link"> ABOUT US</a>
                    </li>
                      <li class="nav-item">
                        <a href="#services" class="nav-link">SERVICES</a>
                    </li>
                    <li class="nav-item">
                        <a href="#quatation" class="nav-link">ORDERFORM</a>
                    </li>
                    <li class="nav-item">
                        <a href="#product" class="nav-link">PRODUCT</a>
                    </li>
                    <li class="nav-item">
                        <a href="#team" class="nav-link">OUR TEAM</a>
                    </li>
                    <li class="nav-item">
                        <a href="#contact" class="nav-link">CONTACT</a>
                    </li>
                      <li class="nav-item">
                        <a href="/login" class="nav-link">LOGIN PORTAL</a>
                    </li>
                </ul>
            </div>
          </nav>
      </div>
  </div>
</div>
</div>


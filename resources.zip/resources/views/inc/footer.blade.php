<div id="footer" class="footer">
	<div class="container">
		<div class="row">
			 <div class="col-lg-4 col-md-4">
			 	<h4><span id="titleColorAboutUs">Contact</span> Us</h4>
			 	<p><i class="fas fa-home"> </i> <small>Himlayan Road Tandang Sora, Quezon City</small></p>
			 	<p><i class="fas fa-envelope"> </i> ecopapercorporation@gmail.com</p>
			 	<p><i class="fa fa-phone"> </i> +63 917 659 5588</p>
			 	<p><i class="fa fa-globe"> </i> ecogroup@gmail.com</p>
			 </div>
			  <div class="col-lg-4 col-md-4">
			 	<h4>About</h4>
			 	<p><i class="far fa-square"> </i> About Us</p>
			 	<p><i class="far fa-square"> </i> Privacy</p>
			 	<p><i class="far fa-square"> </i> Term & Condition </p>
			 </div>
			 <div class="col-lg-4 col-md-4">
			 	<h4 id="footerStayInTouch"><span id="titleColorAboutUs">Stay</span> in touch:</h4>
			 	<i class="fab social fa-facebook-f"></i>
			 	<i class="fab social fa-instagram"></i>
			 	<i class="fab social fa-twitter"></i>
			 	<i class="far social fa-envelope" id="socialEnvelope"></i>
			 	{{-- <input type="email" placeholder="Subcribe for more updates"><button class="btn btn-success">Subscribe</button> --}}
			 </div>
		</div>
		<hr id="divider">
		<p class="text-center">© Copyright 2019 EcoPaper&Printing - All rights reserved.</p>
	</div>
</div>